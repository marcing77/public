# 📋 PAKIET SZABLONÓW RAPORTÓW AUDYTOWYCH ISO 27001

Kompletny zestaw narzędzi do tworzenia profesjonalnych raportów audytowych zgodnych z ISO 27001:2022, NIS2, DORA i RODO.

---

## 📦 ZAWARTOŚĆ PAKIETU

```
.
├── README.md                          ← Ten plik
├── SZABLON_RAPORT_AUDYTOWY.md        ← Szablon Markdown
├── SZABLON_RAPORT_HTML.html          ← Szablon HTML (do PDF)
├── INSTRUKCJA_SZABLON.md             ← Szczegółowa instrukcja
└── generate_audit_report.sh          ← Skrypt pomocniczy
```

---

## 🚀 QUICK START

### Metoda 1: Automatyczna (ZALECANE)

```bash
# 1. Uruchom generator
chmod +x generate_audit_report.sh
./generate_audit_report.sh

# 2. Odpowiedz na pytania:
#    - Nazwa kontroli: MFA
#    - System: Azure AD
#    - Firma: Twoja firma
#    - Audytor: Twoje dane
#    - Format: 3 (oba)

# 3. Otrzymasz gotowe pliki:
#    - Raport_MFA_2026-01-19.md
#    - Raport_MFA_2026-01-19.html
#    - Raport_MFA_2026-01-19.pdf (opcjonalnie)
```

### Metoda 2: Manualna

```bash
# 1. Skopiuj szablon
cp SZABLON_RAPORT_AUDYTOWY.md Raport_MFA_2026-01-19.md

# 2. Edytuj w ulubionym edytorze
vim Raport_MFA_2026-01-19.md

# 3. Wypełnij wszystkie placeholdery [...]
```

---

## 📖 DOKUMENTACJA

### SZABLON_RAPORT_AUDYTOWY.md
Szablon w formacie Markdown z wszystkimi wymaganymi sekcjami:

**Sekcje:**
1. Cel audytu
2. Zakres audytu
3. Metodologia
4. Wyniki audytu (szczegółowe)
5. Ocena ryzyka
6. Rekomendacje (krótko/średnio/długoterminowe)
7. Podsumowanie
8. Załączniki
9. Metadane dokumentu
10. Zatwierdzenia

**Format placeholderów:**
- `[NAZWA KONTROLI]` → Zamień na nazwę audytowanej kontroli
- `[System/Obszar]` → Zamień na nazwę systemu
- `[DD miesiąc RRRR]` → Zamień na datę
- itd.

---

### SZABLON_RAPORT_HTML.html
Szablon HTML z profesjonalnym stylem CSS, gotowy do konwersji na PDF.

**Cechy:**
- ✅ Responsywny design A4
- ✅ Kolorowe status boxy (sukces/warning/danger)
- ✅ Tabele z formatowaniem
- ✅ Miejsca na screenshoty
- ✅ Żółte podświetlenia placeholderów
- ✅ Gotowy do wkhtmltopdf

**Generowanie PDF:**
```bash
wkhtmltopdf \
  --enable-local-file-access \
  --page-size A4 \
  --margin-top 15mm \
  --margin-bottom 15mm \
  --margin-left 15mm \
  --margin-right 15mm \
  Raport_MFA_2026-01-19.html \
  Raport_MFA_2026-01-19.pdf
```

---

### INSTRUKCJA_SZABLON.md
Kompleksowy przewodnik z:

- 📝 Jak wypełniać każdą sekcję
- 🎯 Mapowanie kontroli ISO 27001/NIS2/DORA/RODO
- 📊 Matryca oceny ryzyka
- ✅ Checklist przed finalizacją
- 💡 Best practices
- 🆘 Troubleshooting

**Przeczytaj to ZAWSZE przed pierwszym użyciem!**

```bash
cat INSTRUKCJA_SZABLON.md | less
```

---

### generate_audit_report.sh
Interaktywny skrypt do szybkiego tworzenia raportów.

**Co robi:**
1. Zbiera podstawowe informacje (nazwa, data, audytor)
2. Kopiuje szablon
3. Automatycznie wypełnia podstawowe placeholdery
4. Opcjonalnie generuje PDF

**Użycie:**
```bash
chmod +x generate_audit_report.sh
./generate_audit_report.sh
```

---

## 📚 PRZYKŁADY UŻYCIA

### Przykład 1: Audyt MFA

```bash
./generate_audit_report.sh

# Wpisz:
Nazwa kontroli: Multi-Factor Authentication (MFA)
System: Microsoft Azure AD / Entra ID
Firma: Przykładowa Firma Sp. z o.o.
Audytor: Jan Kowalski
Format: 3

# Otrzymasz:
# - Raport_Multi-Factor_Authentication_(MFA)_2026-01-19.md
# - Raport_Multi-Factor_Authentication_(MFA)_2026-01-19.html
# - Raport_Multi-Factor_Authentication_(MFA)_2026-01-19.pdf
```

### Przykład 2: Audyt backupów

```bash
cp SZABLON_RAPORT_AUDYTOWY.md Raport_Backup_2026-01-19.md

# Edytuj ręcznie:
vim Raport_Backup_2026-01-19.md

# Wypełnij:
- [NAZWA KONTROLI] → BACKUP I RECOVERY
- [System/Obszar] → Veeam Backup & Replication
- [ISO kontrole] → 8.13, 8.14
- itd.
```

---

## 🎨 PERSONALIZACJA

### Zmiana stylu CSS (HTML template)

Edytuj sekcję `<style>` w `SZABLON_RAPORT_HTML.html`:

```css
/* Zmiana koloru głównego */
h1 {
    color: #0078D4;  /* ← Twój kolor */
    border-bottom: 3px solid #0078D4;
}

/* Zmiana fontu */
body {
    font-family: 'Arial', sans-serif;  /* ← Twój font */
}
```

### Dodanie logo firmy

W HTML template, dodaj po `<body>`:

```html
<div style="text-align: center; margin-bottom: 30px;">
    <img src="logo.png" alt="Logo firmy" style="max-width: 200px;">
</div>
```

---

## ✅ CHECKLIST PRZED WYSŁANIEM RAPORTU

Przed finalizacją sprawdź:

- [ ] Wszystkie placeholdery `[...]` wypełnione
- [ ] Daty w jednolitym formacie
- [ ] Załączniki dołączone i opisane
- [ ] Compliance mapping kompletne
- [ ] Rekomendacje mają ownera + deadline
- [ ] Poziom ryzyka uzasadniony
- [ ] Sprawdzenie ortografii
- [ ] Numeracja załączników poprawna
- [ ] Metadane dokumentu wypełnione
- [ ] Miejsce na podpisy

---

## 🔧 WYMAGANIA TECHNICZNE

### Do pracy z Markdown:
- Dowolny edytor tekstu
- (Opcjonalnie) Pandoc do konwersji do PDF

### Do pracy z HTML:
- Przeglądarka do podglądu
- `wkhtmltopdf` do generowania PDF:
  ```bash
  # macOS
  brew install wkhtmltopdf
  
  # Ubuntu/Debian
  sudo apt-get install wkhtmltopdf
  
  # Windows
  # Pobierz z: https://wkhtmltopdf.org/downloads.html
  ```

---

## 📞 WSPARCIE

**Pytania?**
Sprawdź INSTRUKCJA_SZABLON.md sekcja "Troubleshooting"

**Problemy z PDF?**
```bash
# Test wkhtmltopdf
wkhtmltopdf --version

# Jeśli nie działa, zainstaluj ponownie
brew reinstall wkhtmltopdf
```

---

## 📋 STANDARDY I COMPLIANCE

Szablony zawierają mapowanie na:

### ISO/IEC 27001:2022
- Annex A Controls (wszystkie sekcje)
- Szczególnie: 5.17, 5.18, 8.2, 8.3, 8.5, 8.8

### NIS2 Directive
- Art. 21 (Cybersecurity risk management)
- Wszystkie podpunkty (a)-(h)

### DORA
- Art. 9 (ICT risk management framework)
- Art. 11 (Business continuity)

### RODO
- Art. 32 (Security of processing)
- Art. 33 (Breach notification)
- Art. 35 (DPIA)

---

## 📁 PRZECHOWYWANIE

**Zgodnie z ISO 27001:**
- Okres przechowywania: **minimum 7 lat**
- Lokalizacja: Bezpieczne repozytorium dokumentów
- Klasyfikacja: INTERNAL lub CONFIDENTIAL
- Backup: Tak, regularnie

**Nazewnictwo plików:**
```
Raport_[Kontrola]_[Firma]_[RRRR-MM-DD]_v[X.Y].pdf

Przykład:
Raport_MFA_ExampleCorp_2026-01-19_v1.0.pdf
```

---

## 🔄 WERSJONOWANIE

**Format wersji:** vX.Y

- **X** (major) - Znaczące zmiany, nowe sekcje, zmiana wniosków
- **Y** (minor) - Drobne poprawki, aktualizacja danych, literówki

**Przykład:**
- v1.0 → Pierwsza wersja
- v1.1 → Poprawka literówek
- v1.2 → Dodanie jednego załącznika
- v2.0 → Zmiana wniosków audytu, nowe rekomendacje

---

## 📅 HARMONOGRAM PRZEGLĄDÓW

**Zalecane:**
- **Kwartalnie** - Kontrole krytyczne (MFA, backups, access rights)
- **Półrocznie** - Kontrole średniego ryzyka
- **Rocznie** - Kontrole niskiego ryzyka + wszystkie przed audytem

**Używaj pola "Następny przegląd" w metadanych dokumentu!**

---

## 🎯 BEST PRACTICES

1. **Zawsze dodawaj dowody** - Każde twierdzenie = screenshot/log
2. **Bądź konkretny** - Unikaj "działa dobrze", podaj liczby/daty
3. **Używaj tabel** - Dla wielu podobnych elementów
4. **Priorytetyzuj** - Nie wszystko jest krytyczne
5. **Executive summary** - Sekcja 7 powinna być self-contained
6. **Zachowaj spójność** - Te same terminy w całym dokumencie
7. **Version control** - Git dla raportów = dobry pomysł
8. **Peer review** - Poproś kogoś o przejrzenie przed wysłaniem

---

## 📖 DODATKOWE ZASOBY

**ISO 27001:2022:**
- [ISO.org - Standard](https://www.iso.org/standard/27001)
- [Annex A Controls](https://www.isms.online/iso-27001/annex-a/)

**NIS2 Directive:**
- [EUR-Lex - Official text](https://eur-lex.europa.eu/eli/dir/2022/2555)

**DORA:**
- [EUR-Lex - Official text](https://eur-lex.europa.eu/eli/reg/2022/2554)

**Tools:**
- [Pandoc](https://pandoc.org/) - Document converter
- [wkhtmltopdf](https://wkhtmltopdf.org/) - HTML to PDF

---

## 📜 LICENCJA

Ten pakiet szablonów jest własnością wewnętrzną i przeznaczony do użytku w ramach procesów compliance.

**Użycie:**
- ✅ Wewnętrzne audyty
- ✅ Dokumentacja ISO 27001
- ✅ Przygotowanie do certyfikacji
- ✅ Modyfikacja dla własnych potrzeb

---

## 📝 CHANGELOG

**v1.0 - 2026-01-19**
- Pierwsza wersja pakietu szablonów
- Szablon Markdown + HTML
- Instrukcja użycia
- Skrypt generatora
- Mapowanie ISO 27001/NIS2/DORA/RODO

---

## 🎉 GOTOWE DO UŻYCIA!

```bash
# Zacznij teraz:
./generate_audit_report.sh

# Lub przeczytaj instrukcję:
cat INSTRUKCJA_SZABLON.md

# Potrzebujesz pomocy?
cat INSTRUKCJA_SZABLON.md | grep -A 10 "Troubleshooting"
```

**Powodzenia z audytami! 🚀**

---

*Ostatnia aktualizacja: 19 stycznia 2026*  
*Wersja pakietu: 1.0*  
*Utworzone przez: Jan Kowalski, IT Manager*
