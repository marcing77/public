#!/bin/bash
# generate_audit_report.sh
# Pomocnik do generowania raportów audytowych z szablonu

set -e

echo "╔════════════════════════════════════════════════════════╗"
echo "║     Generator Raportów Audytowych ISO 27001            ║"
echo "╚════════════════════════════════════════════════════════╝"
echo ""

# Funkcja do pytania użytkownika
ask() {
    local prompt="$1"
    local default="$2"
    local result
    
    if [ -n "$default" ]; then
        read -p "$prompt [$default]: " result
        echo "${result:-$default}"
    else
        read -p "$prompt: " result
        echo "$result"
    fi
}

# Zbierz podstawowe informacje
echo "=== PODSTAWOWE INFORMACJE ==="
echo ""

KONTROLA=$(ask "Nazwa kontroli (np. MFA, Backup, Access Review)")
SYSTEM=$(ask "System/Obszar (np. Azure AD, AWS, Aplikacja X)")
FIRMA=$(ask "Nazwa firmy" "Przykładowa Firma Sp. z o.o.")
AUDYTOR=$(ask "Imię i nazwisko audytora" "Jan Kowalski")
DATA=$(date +"%Y-%m-%d")
DATA_PL=$(date +"%d %B %Y" | sed 's/January/stycznia/; s/February/lutego/; s/March/marca/; s/April/kwietnia/; s/May/maja/; s/June/czerwca/; s/July/lipca/; s/August/sierpnia/; s/September/września/; s/October/października/; s/November/listopada/; s/December/grudnia/')

echo ""
echo "=== WYBIERZ FORMAT ==="
echo "1) Markdown (.md)"
echo "2) HTML (.html)"
echo "3) Oba"
echo ""

FORMAT=$(ask "Wybór" "3")

# Utwórz nazwę pliku
FILENAME_BASE="Raport_${KONTROLA// /_}_${DATA}"

echo ""
echo "=== GENEROWANIE... ==="
echo ""

# Funkcja do zastąpienia placeholderów
replace_placeholders() {
    local file="$1"
    
    sed -i.bak \
        -e "s/\[NAZWA KONTROLI\]/${KONTROLA}/g" \
        -e "s/\[System\/Obszar\]/${SYSTEM}/g" \
        -e "s/\[Nazwa firmy\]/${FIRMA}/g" \
        -e "s/\[DD miesiąc RRRR\]/${DATA_PL}/g" \
        -e "s/\[Imię Nazwisko\]/${AUDYTOR}/g" \
        -e "s/\[RRRR-MM-DD\]/${DATA}/g" \
        "$file"
    
    rm "${file}.bak" 2>/dev/null || true
}

# Generuj Markdown
if [ "$FORMAT" = "1" ] || [ "$FORMAT" = "3" ]; then
    if [ -f "SZABLON_RAPORT_AUDYTOWY.md" ]; then
        cp SZABLON_RAPORT_AUDYTOWY.md "${FILENAME_BASE}.md"
        replace_placeholders "${FILENAME_BASE}.md"
        echo "✅ Utworzono: ${FILENAME_BASE}.md"
    else
        echo "❌ Brak pliku SZABLON_RAPORT_AUDYTOWY.md"
    fi
fi

# Generuj HTML
if [ "$FORMAT" = "2" ] || [ "$FORMAT" = "3" ]; then
    if [ -f "SZABLON_RAPORT_HTML.html" ]; then
        cp SZABLON_RAPORT_HTML.html "${FILENAME_BASE}.html"
        replace_placeholders "${FILENAME_BASE}.html"
        echo "✅ Utworzono: ${FILENAME_BASE}.html"
        
        # Zapytaj czy wygenerować PDF
        echo ""
        read -p "Czy wygenerować PDF z HTML? (t/n): " GEN_PDF
        
        if [ "$GEN_PDF" = "t" ] || [ "$GEN_PDF" = "T" ]; then
            if command -v wkhtmltopdf &> /dev/null; then
                wkhtmltopdf \
                    --enable-local-file-access \
                    --page-size A4 \
                    --margin-top 15mm \
                    --margin-bottom 15mm \
                    --margin-left 15mm \
                    --margin-right 15mm \
                    "${FILENAME_BASE}.html" \
                    "${FILENAME_BASE}.pdf"
                echo "✅ Utworzono: ${FILENAME_BASE}.pdf"
            else
                echo "❌ Brak wkhtmltopdf - zainstaluj: brew install wkhtmltopdf"
            fi
        fi
    else
        echo "❌ Brak pliku SZABLON_RAPORT_HTML.html"
    fi
fi

echo ""
echo "=== NASTĘPNE KROKI ==="
echo ""
echo "1. Edytuj plik i wypełnij pozostałe placeholdery [...]"
echo "2. Dodaj screenshoty jako załączniki"
echo "3. Wypełnij sekcje 4-6 szczegółowymi ustaleniami"
echo "4. Przejrzyj checklist w INSTRUKCJA_SZABLON.md"
echo ""
echo "📖 Szczegółowe instrukcje: cat INSTRUKCJA_SZABLON.md"
echo ""
echo "Gotowe! 🎉"
