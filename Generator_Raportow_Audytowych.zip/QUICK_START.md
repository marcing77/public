# 🚀 QUICK START - Pakiet Szablonów Raportów Audytowych

## 📦 CO OTRZYMAŁEŚ?

**Pakiet Szablonow Raportow Audytowych.zip** zawiera:

1. **README.md** - Pełna dokumentacja pakietu
2. **INSTRUKCJA_SZABLON.md** - Szczegółowy przewodnik wypełniania
3. **SZABLON_RAPORT_AUDYTOWY.md** - Szablon Markdown
4. **SZABLON_RAPORT_HTML.html** - Szablon HTML (do PDF)
5. **generate_audit_report.sh** - Skrypt pomocniczy

---

## ⚡ UŻYCIE W 3 KROKACH

### KROK 1: Rozpakuj archiwum

```bash
unzip Pakiet_Szablonow_Raportow_Audytowych.zip -d RaportyAudytowe
cd RaportyAudytowe
```

### KROK 2: Uruchom generator

```bash
chmod +x generate_audit_report.sh
./generate_audit_report.sh
```

### KROK 3: Wypełnij szczegóły

Edytuj utworzony plik i zamień wszystkie placeholdery `[...]`

```bash
# Otwórz w edytorze
vim Raport_*.md
# LUB
open Raport_*.html
```

---

## 📝 PRZYKŁAD UŻYCIA

```bash
$ ./generate_audit_report.sh

Nazwa kontroli: MFA
System/Obszar: Azure AD
Nazwa firmy: Przykładowa Firma Sp. z o.o.
Audytor: Jan Kowalski
Format: 3

✅ Utworzono: Raport_MFA_2026-01-19.md
✅ Utworzono: Raport_MFA_2026-01-19.html
✅ Utworzono: Raport_MFA_2026-01-19.pdf
```

Gotowy raport w 30 sekund! 🎉

---

## 📚 DOKUMENTACJA

**Pytania o wypełnianie?** → Czytaj `INSTRUKCJA_SZABLON.md`

**Chcesz wiedzieć wszystko?** → Czytaj `README.md`

**Potrzebujesz przykładu?** → Zobacz wygenerowany raport MFA

---

## 💡 WSKAZÓWKI

### Dla początkujących:
1. Zacznij od `README.md` (przegląd)
2. Przeczytaj `INSTRUKCJA_SZABLON.md` (szczegóły)
3. Użyj `generate_audit_report.sh` (automatyzacja)

### Dla zaawansowanych:
1. Skopiuj szablon bezpośrednio
2. Edytuj w swoim ulubionym edytorze
3. Dostosuj CSS/formatowanie pod siebie

---

## 🔧 WYMAGANIA

**Minimalne:**
- Edytor tekstu (vim, nano, VS Code, Notepad++)

**Opcjonalne (dla PDF):**
```bash
# macOS
brew install wkhtmltopdf

# Linux
sudo apt-get install wkhtmltopdf
```

---

## ✅ GŁÓWNE SEKCJE RAPORTU

Każdy raport zawiera:

1. **Cel audytu** - Co sprawdzasz i dlaczego
2. **Zakres** - Lista rzeczy do weryfikacji
3. **Metodologia** - Jak przeprowadziłeś audyt
4. **Wyniki** - Szczegółowe findings
5. **Ocena ryzyka** - NISKI/ŚREDNI/WYSOKI/KRYTYCZNY
6. **Rekomendacje** - Co trzeba poprawić
7. **Podsumowanie** - Executive summary
8. **Załączniki** - Dowody (screenshoty, logi)

---

## 🎯 COMPLIANCE

Szablony mapują na:

- ✅ **ISO 27001:2022** (Annex A)
- ✅ **NIS2 Directive** (Art. 21)
- ✅ **DORA** (Art. 9, 11)
- ✅ **RODO** (Art. 32, 33, 35)

---

## 📞 PROBLEMY?

**Skrypt nie działa:**
```bash
chmod +x generate_audit_report.sh
bash generate_audit_report.sh
```

**Nie możesz wygenerować PDF:**
```bash
# Sprawdź czy masz wkhtmltopdf
which wkhtmltopdf

# Jeśli nie, zainstaluj
brew install wkhtmltopdf
```

**Inne pytania:**
Sprawdź sekcję "Troubleshooting" w `INSTRUKCJA_SZABLON.md`

---

## 🌟 NAJLEPSZE PRAKTYKI

1. **Zawsze dołączaj screenshoty** - Każde twierdzenie = dowód
2. **Bądź konkretny** - Podawaj liczby, daty, konkretne wartości
3. **Priorytetyzuj** - Nie wszystko jest krytyczne
4. **Review przed wysłaniem** - Checklist w instrukcji
5. **Wersjonuj dokumenty** - Format: v1.0, v1.1, v2.0

---

## 📁 STRUKTURA PROJEKTU

```
RaportyAudytowe/
├── README.md                          # Pełna dokumentacja
├── INSTRUKCJA_SZABLON.md             # Przewodnik wypełniania
├── SZABLON_RAPORT_AUDYTOWY.md        # Szablon Markdown
├── SZABLON_RAPORT_HTML.html          # Szablon HTML
├── generate_audit_report.sh          # Generator
└── raporty/                          # Twoje raporty (tutaj)
    ├── Raport_MFA_2026-01-19.pdf
    ├── Raport_Backup_2026-01-20.pdf
    └── ...
```

---

## 🎓 PRZYKŁADOWE AUDYTY

### Gotowe szablony dla:
- ✅ Multi-Factor Authentication (MFA)
- ✅ Backup & Recovery
- ✅ Access Review / Inwentaryzacja dostępów
- ✅ Patch Management
- ✅ Incident Response
- ✅ Network Security
- ✅ Data Encryption

**Każdy można dostosować pod swoje potrzeby!**

---

## 🚀 ZACZNIJ TERAZ!

```bash
# 1. Rozpakuj
unzip Pakiet_Szablonow_Raportow_Audytowych.zip

# 2. Wejdź do katalogu
cd RaportyAudytowe

# 3. Uruchom generator
./generate_audit_report.sh

# 4. Wypełnij szczegóły
vim Raport_*.md

# 5. Gotowe!
```

---

**Pytania? Zobacz `README.md` i `INSTRUKCJA_SZABLON.md`**

**Powodzenia! 🎉**
