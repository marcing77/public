# RAPORT AUDYTOWY - [NAZWA KONTROLI]
## [System/Obszar]

---

**ORGANIZACJA:** [Nazwa firmy]  
**DATA AUDYTU:** [DD miesiąc RRRR]  
**AUDYTOR:** [Imię Nazwisko], IT Manager  
**IDENTYFIKATOR:** [ID systemu/tenanta jeśli dotyczy]  
**DOMENA/ZAKRES:** [domena.com lub opis zakresu]

---

## 1. CEL AUDYTU

Weryfikacja [opis kontroli/systemu] w ramach wymagań:

- **ISO/IEC 27001:2022** - Kontrola [numer kontroli, np. 5.17, 5.18]
- **NIS2 Directive** - [Art. XX jeśli dotyczy]
- **DORA** - [Art. XX jeśli dotyczy]
- **RODO** - [Art. XX jeśli dotyczy]

---

## 2. ZAKRES AUDYTU

✓ [Element 1 do weryfikacji]  
✓ [Element 2 do weryfikacji]  
✓ [Element 3 do weryfikacji]  
✓ [Element 4 do weryfikacji]  
✓ [Element 5 do weryfikacji]  

---

## 3. METODOLOGIA

Audyt przeprowadzono poprzez:
- [Metoda 1, np. Inspekcja interfejsu administracyjnego]
- [Metoda 2, np. Przegląd logów systemowych]
- [Metoda 3, np. Testy funkcjonalne]
- [Metoda 4, np. Analiza konfiguracji]

**ŹRÓDŁO DANYCH:**  
[Opis źródeł danych, np. Panel administracyjny XYZ, baza danych, logi]

---

## 4. WYNIKI AUDYTU

### 4.1 [NAZWA PIERWSZEGO OBSZARU] - STATUS

**STATUS: [WŁĄCZONE/WYŁĄCZONE/CZĘŚCIOWE]** [✅/❌/⚠️]

**Potwierdzenie:**
> "[Cytat z systemu lub opis stanu faktycznego]"

**Data weryfikacji:** [RRRR-MM-DD]  
**Metoda:** [Jak zweryfikowano]

**Kluczowe parametry:**
- [Parametr 1]: [wartość]
- [Parametr 2]: [wartość]
- [Parametr 3]: [wartość]

**Dowód:** Zobacz Załącznik A - [opis załącznika]

---

### 4.2 [NAZWA DRUGIEGO OBSZARU]

**[Opis szczegółowych ustaleń dla tego obszaru]**

✅ [Ustalenie pozytywne 1]  
✅ [Ustalenie pozytywne 2]  
❌ [Ustalenie negatywne 1] - **WYMAGA DZIAŁAŃ**  
⚠️ [Ustalenie wymagające uwagi]

---

### 4.3 [NAZWA TRZECIEGO OBSZARU]

[Tabela z wynikami jeśli dotyczy]

| Element | Status | Uwagi |
|---------|--------|-------|
| [Element 1] | ✅ Spełnione | [komentarz] |
| [Element 2] | ✅ Spełnione | [komentarz] |
| [Element 3] | ❌ Niespełnione | [komentarz] |

---

### 4.4 COMPLIANCE MAPPING

| Standard/Regulacja | Wymaganie | Status |
|-------------------|-----------|---------|
| **ISO 27001:2022** | Kontrola X.XX - [opis] | ✅ Spełnione |
| **ISO 27001:2022** | Kontrola X.XX - [opis] | ✅ Spełnione |
| **NIS2 Directive** | Art. XX - [opis] | ✅ Spełnione |
| **DORA** | Art. XX - [opis] | ✅ Spełnione |
| **RODO** | Art. XX - [opis] | ✅ Spełnione |

---

## 5. OCENA RYZYKA

**POZIOM RYZYKA: [NISKI/ŚREDNI/WYSOKI/KRYTYCZNY]** [✅/⚠️/❌]

**UZASADNIENIE:**
- [Czynnik ryzyka 1]
- [Czynnik ryzyka 2]
- [Czynnik ryzyka 3]
- [Czynnik mitygujący 1]
- [Czynnik mitygujący 2]

**WPŁYW NA BIZNES:**
- [Opis potencjalnego wpływu]

**PRAWDOPODOBIEŃSTWO:**
- [Opis prawdopodobieństwa materializacji ryzyka]

---

## 6. REKOMENDACJE

### 6.1 KRÓTKOTERMINOWE (0-3 miesiące)

**PRIORYTET: [KRYTYCZNY/WYSOKI/ŚREDNI/NISKI]**

**Wymagane działania:**
- [ ] [Działanie 1]
  - **Odpowiedzialny:** [Osoba/Zespół]
  - **Deadline:** [Data]
  - **Koszt:** [Szacunek]
  
- [ ] [Działanie 2]
  - **Odpowiedzialny:** [Osoba/Zespół]
  - **Deadline:** [Data]
  - **Koszt:** [Szacunek]

**Opcjonalne:**
- [ ] [Opcjonalne działanie 1]
- [ ] [Opcjonalne działanie 2]

---

### 6.2 ŚREDNIOTERMINOWE (3-6 miesięcy)

**PRIORYTET: [WYSOKI/ŚREDNI/NISKI]**

- [ ] [Działanie 1]
  - **Uzasadnienie:** [Dlaczego]
  - **Korzyści:** [Co zyskamy]
  - **Odpowiedzialny:** [Osoba/Zespół]

- [ ] [Działanie 2]
  - **Uzasadnienie:** [Dlaczego]
  - **Korzyści:** [Co zyskamy]
  - **Odpowiedzialny:** [Osoba/Zespół]

---

### 6.3 DŁUGOTERMINOWE (6-12 miesięcy)

**PRIORYTET: [ŚREDNI/NISKI]**

- [ ] [Działanie 1]
- [ ] [Działanie 2]
- [ ] [Działanie 3]

---

## 7. PODSUMOWANIE

**STATUS KONTROLI:** [✅ SPEŁNIONE / ⚠️ CZĘŚCIOWO SPEŁNIONE / ❌ NIESPEŁNIONE]

[Krótkie podsumowanie 2-3 zdania o stanie kontroli]

**Konfiguracja spełnia wymagania:**
- [✅/❌/⚠️] ISO/IEC 27001:2022
- [✅/❌/⚠️] NIS2 Directive
- [✅/❌/⚠️] DORA
- [✅/❌/⚠️] RODO Art. 32

**RYZYKO:** [AKCEPTOWALNE / WYMAGA MITYGACJI / WYSOKIE]  
**DZIAŁANIA KORYGUJĄCE:** [Brak / Zobacz sekcja 6 / Wymagane natychmiastowe działania]

---

## 8. ZAŁĄCZNIKI

- **Załącznik A:** [Opis załącznika 1, np. Screenshot konfiguracji]
- **Załącznik B:** [Opis załącznika 2, np. Log systemowy]
- **Załącznik C:** [Opis załącznika 3, np. Lista użytkowników]

---

## 9. METADANE DOKUMENTU

| Pole | Wartość |
|------|---------|
| **Wersja dokumentu** | 1.0 |
| **Data utworzenia** | [DD miesiąc RRRR] |
| **Klasyfikacja** | INTERNAL / CONFIDENTIAL |
| **Okres przechowywania** | 7 lat (wymagania ISO 27001) |
| **Właściciel dokumentu** | IT Manager |
| **Następny przegląd** | [Data za rok] |

---

## 10. ZATWIERDZENIA

**Sporządził:**  
[Imię Nazwisko]  
IT Manager  
Data: [DD miesiąc RRRR]  
Podpis: ________________________

**Zatwierdził:**  
_______________________________  
[Imię i nazwisko]  
[Stanowisko]  
Data: _______________  
Podpis: ________________________

---

**KONIEC RAPORTU**

---

*Dokument wygenerowany w ramach procesu audytu zgodności z ISO 27001:2022, NIS2, DORA i RODO.*
