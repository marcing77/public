# INSTRUKCJA UŻYCIA SZABLONU RAPORTU AUDYTOWEGO

## 📋 Przegląd

Ten szablon służy do dokumentowania audytów kontroli bezpieczeństwa w ramach ISO 27001, NIS2, DORA i RODO.

---

## 🚀 Szybki Start

### Krok 1: Skopiuj szablon
```bash
cp SZABLON_RAPORT_AUDYTOWY.md Raport_[NAZWA]_[DATA].md
```

### Krok 2: Wypełnij placeholdery

Wyszukaj i zastąp wszystkie elementy w nawiasach kwadratowych `[...]`:

**Nagłówek dokumentu:**
- `[NAZWA KONTROLI]` → np. "MULTI-FACTOR AUTHENTICATION (MFA)"
- `[System/Obszar]` → np. "Microsoft Azure AD / Entra ID"
- `[Nazwa firmy]` → np. "Example Corp Sp. z o.o."
- `[DD miesiąc RRRR]` → np. "19 stycznia 2026"
- `[Imię Nazwisko]` → Twoje dane

### Krok 3: Dostosuj sekcje

- Usuń nieużywane sekcje
- Dodaj własne sekcje jeśli potrzeba
- Dostosuj tabele do swojego przypadku

### Krok 4: Dołącz dowody

- Screenshoty → zapisz jako PNG/JPG
- Logi → zapisz jako TXT lub załącz fragment
- Konfiguracje → export jako JSON/XML

### Krok 5: Wygeneruj PDF

```bash
# Jeśli masz pandoc:
pandoc Raport_[NAZWA]_[DATA].md -o Raport_[NAZWA]_[DATA].pdf

# LUB użyj HTML template (zobacz niżej)
```

---

## 📝 Przewodnik po sekcjach

### Sekcja 1: CEL AUDYTU
**Co wpisać:**
- Krótki opis co audytujesz (1-2 zdania)
- Lista relevantnych standardów i kontroli
- Konkretne numery artykułów/kontroli

**Przykład:**
```
Weryfikacja wymuszania Multi-Factor Authentication (MFA) 
w środowisku Microsoft Azure AD/Entra ID w ramach wymagań:

- ISO/IEC 27001:2022 - Kontrola 5.17, 5.18, 8.5
- NIS2 Directive - Art. 21 (Cybersecurity risk management)
```

---

### Sekcja 2: ZAKRES AUDYTU
**Co wpisać:**
- Lista rzeczy które sprawdzasz (5-8 punktów)
- Każdy punkt zaczyna się od ✓

**Przykład:**
```
✓ Konfiguracja Security Defaults
✓ Polityki Conditional Access
✓ Wymuszanie MFA dla adminów
✓ Dostępne metody uwierzytelniania
```

---

### Sekcja 3: METODOLOGIA
**Co wpisać:**
- Jak przeprowadziłeś audyt
- Jakie narzędzia użyłeś
- Gdzie sprawdzałeś dane

**Przykład:**
```
Audyt przeprowadzono poprzez:
- Bezpośrednią inspekcję Azure Portal
- Przegląd logów z Sentinel
- Testy funkcjonalne z 5 kontami testowymi

ŹRÓDŁO DANYCH:
Azure Portal > Microsoft Entra ID > Properties
```

---

### Sekcja 4: WYNIKI AUDYTU
**Co wpisać:**
- Szczegółowe findings dla każdego obszaru
- Używaj emoji: ✅ (OK), ❌ (Problem), ⚠️ (Uwaga)
- Załącz screenshoty jako dowody

**Struktura:**
```
### 4.1 [OBSZAR 1] - STATUS

STATUS: WŁĄCZONE ✅

Potwierdzenie:
> "[Cytat z systemu]"

Data weryfikacji: 2026-01-19
Metoda: Inspekcja panelu admin

Dowód: Zobacz Załącznik A
```

**Tabela dla wielu elementów:**
```
| Element | Status | Uwagi |
|---------|--------|-------|
| MFA dla adminów | ✅ | Zawsze wymagane |
| MFA dla users | ⚠️ | Risk-based tylko |
| Legacy auth | ✅ | Zablokowane |
```

---

### Sekcja 4.4: COMPLIANCE MAPPING
**Co wpisać:**
- Mapowanie na konkretne kontrole ISO/NIS2/DORA/RODO
- Status dla każdej kontroli

**Szybkie odniesienia:**

**ISO 27001:2022 - Najczęstsze kontrole:**
- 5.1 - Policies for information security
- 5.17 - Authentication information
- 5.18 - Access rights
- 8.2 - Privileged access rights
- 8.3 - Information access restriction
- 8.5 - Secure authentication
- 8.8 - Management of technical vulnerabilities
- 8.16 - Monitoring activities

**NIS2 Directive - Art. 21(2):**
- (a) - Risk analysis and information security policies
- (b) - Incident handling
- (c) - Business continuity
- (d) - Supply chain security and MFA
- (e) - Security in network and information systems acquisition
- (f) - Policies on cryptography
- (g) - Personnel security, training
- (h) - Policies on access control

**DORA - Art. 9:**
- (1) - ICT risk management framework
- (4) - ICT security policies
- (5) - Authentication and cryptography

**RODO:**
- Art. 32 - Security of processing
- Art. 33 - Notification of personal data breach
- Art. 35 - Data protection impact assessment

---

### Sekcja 5: OCENA RYZYKA

**Poziomy ryzyka:**
- **KRYTYCZNY** ❌ - Wymaga natychmiastowej akcji
- **WYSOKI** ❌ - Wymaga akcji w ciągu tygodnia
- **ŚREDNI** ⚠️ - Wymaga akcji w ciągu miesiąca
- **NISKI** ✅ - Akceptowalny, opcjonalne ulepszenia

**Uzasadnienie - zawsze uwzględnij:**
- Co może pójść nie tak (threat)
- Jak prawdopodobne (likelihood)
- Jaki wpływ na biznes (impact)
- Jakie mitigation już mamy (controls)

---

### Sekcja 6: REKOMENDACJE

**Struktura działania:**
```
- [ ] [Nazwa działania]
  - **Odpowiedzialny:** [Osoba]
  - **Deadline:** [Data]
  - **Koszt:** [Szacunek]
  - **Uzasadnienie:** [Dlaczego]
  - **Korzyści:** [Co zyskamy]
```

**Priorytety:**
- **KRYTYCZNY** - Wymaga natychmiastowej akcji, rizko wysokie
- **WYSOKI** - Ważne dla compliance, deadline <3 miesiące
- **ŚREDNI** - Ulepszenia, deadline 3-6 miesięcy
- **NISKI** - Nice-to-have, deadline >6 miesięcy

---

### Sekcja 7: PODSUMOWANIE

**Statusy kontroli:**
- ✅ **SPEŁNIONE** - Wszystko OK, brak działań korygujących
- ⚠️ **CZĘŚCIOWO SPEŁNIONE** - Wymaga ulepszeń, ryzyko średnie
- ❌ **NIESPEŁNIONE** - Wymaga natychmiastowych działań, ryzyko wysokie

**Format:**
- 2-3 zdania executive summary
- Krótka lista compliance (✅/❌ dla każdego standardu)
- Poziom ryzyka
- Czy wymagane działania korygujące

---

## 🎨 Generowanie PDF z HTML Template

Do wygenerowania profesjonalnego PDF użyj załączonego HTML template:

```bash
# 1. Wypełnij szablon HTML
cp SZABLON_RAPORT_HTML.html Raport_[NAZWA].html

# 2. Edytuj HTML - zamień placeholdery

# 3. Dodaj screenshoty do tego samego folderu

# 4. Wygeneruj PDF
wkhtmltopdf --enable-local-file-access \
  --page-size A4 \
  --margin-top 15mm \
  --margin-bottom 15mm \
  --margin-left 15mm \
  --margin-right 15mm \
  Raport_[NAZWA].html \
  Raport_[NAZWA].pdf
```

---

## 📸 Najlepsze praktyki dla załączników

### Screenshoty:
- **Format:** PNG (najlepszy dla tekstów)
- **Rozdzielczość:** 1920x1080 lub wyższa
- **Nazewnictwo:** `evidence_[obszar]_[data].png`
- **Zaznaczenia:** Używaj czerwonych ramek/strzałek dla ważnych elementów

### Logi:
- **Format:** TXT lub JSON
- **Długość:** Maksymalnie 50 linii, reszta jako osobny plik
- **Anonimizacja:** Usuń IP, emaile jeśli nie potrzebne

### Konfiguracje:
- **Format:** JSON/XML/YAML
- **Pretty-print:** Zawsze formatuj
- **Komentarze:** Dodaj komentarze dla kluczowych linii

---

## ✅ Checklist przed finalizacją

- [ ] Wszystkie placeholdery `[...]` wypełnione
- [ ] Daty w formacie konsystentnym (DD miesiąc RRRR)
- [ ] Załączniki dołączone i opisane
- [ ] Tabele compliance wypełnione
- [ ] Rekomendacje mają ownera i deadline
- [ ] Poziom ryzyka uzasadniony
- [ ] Podpisy - miejsce na fizyczne podpisy
- [ ] Sprawdzenie ortografii
- [ ] Numeracja załączników poprawna
- [ ] Metadane dokumentu wypełnione

---

## 📚 Przykłady użycia

### Przykład 1: Audyt MFA
```
Tytuł: RAPORT AUDYTOWY - MULTI-FACTOR AUTHENTICATION (MFA)
Obszar: Microsoft Azure AD / Entra ID
Kontrole: ISO 5.17, 5.18, 8.5 | NIS2 Art.21(2)(d)
Wynik: ✅ SPEŁNIONE (Security Defaults enabled)
Ryzyko: NISKIE
```

### Przykład 2: Audyt backupów
```
Tytuł: RAPORT AUDYTOWY - BACKUP I RECOVERY
Obszar: Polityka backupów produkcyjnych
Kontrole: ISO 8.13 | DORA Art.11
Wynik: ⚠️ CZĘŚCIOWO SPEŁNIONE (brak testów restore)
Ryzyko: ŚREDNIE
```

### Przykład 3: Audyt inwentaryzacji
```
Tytuł: RAPORT AUDYTOWY - INWENTARYZACJA DOSTĘPÓW
Obszar: Azure AD + aplikacje SaaS
Kontrole: ISO 5.18, 8.2, 8.3 | NIS2 Art.21(2)(a)
Wynik: ❌ NIESPEŁNIONE (brak access review)
Ryzyko: WYSOKIE
```

---

## 🔄 Wersjonowanie dokumentów

Format nazwy pliku:
```
Raport_[Kontrola]_[Organizacja]_[RRRR-MM-DD]_v[X.Y].pdf

Przykład:
Raport_MFA_ExampleCorp_2026-01-19_v1.0.pdf
```

Przy aktualizacjach:
- Drobne poprawki → zwiększ Y (v1.0 → v1.1)
- Większe zmiany → zwiększ X (v1.9 → v2.0)

---

## 💡 Wskazówki

1. **Bądź konkretny** - Unikaj ogólników typu "system działa poprawnie"
2. **Dołącz dowody** - Każde twierdzenie powinno mieć screenshot/log
3. **Używaj tabel** - Dla wielu podobnych elementów
4. **Oznacz priorytety** - Emoji pomagają w szybkim skanie
5. **Executive summary first** - Sekcja 7 powinna być self-contained
6. **Zachowaj spójność** - Używaj tych samych terminów przez cały dokument
7. **Data retention** - Zapisuj raporty na min. 7 lat (ISO 27001)

---

## 🆘 Troubleshooting

**Problem:** Nie wiem jaki poziom ryzyka wybrać
**Rozwiązanie:** Użyj matrycy:
```
           Niskie prawdopodobieństwo | Wysokie prawdopodobieństwo
Wysoki     ŚREDNIE                   | WYSOKIE/KRYTYCZNE
impact     
Niski      NISKIE                    | ŚREDNIE
impact
```

**Problem:** Nie wiem które kontrole ISO wybrać
**Rozwiązanie:** Sprawdź Annex A w ISO 27001:2022 lub użyj mapowania z tej instrukcji

**Problem:** Za długi raport
**Rozwiązanie:** Executive summary (sekcja 7) powinno być max 1 strona. Szczegóły w sekcjach 4-6.

---

## 📞 Kontakt

Pytania? Jan Kowalski, IT Manager

---

**Wersja instrukcji:** 1.0  
**Data ostatniej aktualizacji:** 19 stycznia 2026
